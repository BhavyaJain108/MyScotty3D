#define SDL_REVISION "https://github.com/libsdl-org/SDL.git@53dea9830964eee8b5c2a7ee0a65d6e268dc78a1"
#define SDL_REVISION_NUMBER 0
